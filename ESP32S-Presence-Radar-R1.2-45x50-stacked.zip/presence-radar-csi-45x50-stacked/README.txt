ESP32S Presence Radar：毫米波雷达 + Wi-Fi CSI 辅助
日期：2026-10-14
状态：可编辑的工程样机设计；未经过实物上电与量产验证。

一、设计范围
主控为 ESP32-S3-WROOM-1-N8R8，自带 PCB 天线，无需外接天线。
顶部增加 19.5 x 5.3mm 天线缺口，保留官方封装的天线净空区域；安装孔与接口位置已按紧凑版重新布局。
丝印：www.esp32s.com；PCB manufactured by DIYIPCB（设计标识，不代表已生产）。
雷达为外接 HLK-LD2410C 成熟 24GHz FMCW 模组，本设计不自行设计 24GHz 射频前端。
主板为 45 x 50mm、两层、1.6mm FR-4，四个 M2 安装孔。
USB-C 提供 5V 输入及原生 USB 数据/下载；另有 BOOT、RESET、UART0 救援接口。
AP63203WU-7 将 5V 降为 3.3V；雷达从保险丝后的 5V 供电。
LED 和 I2C 扩展接口已接好；板上没有额外的光照或温湿度传感器。
没有电池、充电管理、市电或继电器电路。

二、打开工程
使用 KiCad 10 打开 presence_radar_csi_r1.kicad_pro。
原理图：presence_radar_csi_r1.kicad_sch
PCB：presence_radar_csi_r1.kicad_pcb
Presence.kicad_sym、sym-lib-table、fp-lib-table 和 libraries/ 是随工程提供的本地库。
预览在 preview/；三维图包含主控模组，外接雷达及连接线未显示。
本地封装和主控模组三维模型路径已随工程保存。

三、接口定义（从主板视角）
J2：1 = 雷达 TX -> MCU GPIO5；2 = 雷达 RX <- MCU GPIO4；
    3 = 雷达 OUT -> MCU GPIO6；4 = GND；5 = 5V。
J2 是 2.54mm 五针母座，支持正确方向直插雷达或通过匹配线缆连接；不要根据方向目测插接。
雷达 UART 默认 256000 baud，3.3V 电平；不能连接 5V 电平的其他串口模块。
GPIO7 控制状态 LED。
J3：1 = 3.3V；2 = GND；3 = GPIO8 SDA；4 = GPIO9 SCL。
J4：1 = GND；2 = GPIO43 UART0 TX；3 = GPIO44 UART0 RX；4 = GPIO10 AUX。
J4 不向外提供电源，不连接 RS-232 电平。
USB D- = GPIO19，D+ = GPIO20。
BOOT = GPIO0，RESET = EN。GPIO35/36/37 为 N8R8 内部 PSRAM 使用，不作外接接口。

四、雷达和 CSI 的关系
雷达是第一版的主要人体存在数据源；CSI 是可关闭的辅助功能。
S3 已支持 Wi-Fi CSI，主板不需要额外 CSI 专用芯片。
CSI 仍需外部 Wi-Fi 数据来源（合适位置的路由器或额外发射节点），不是一个完全独立雷达。
一个 Wi-Fi 射频前端需协调通信和 CSI 的信道/收包任务；不要默认能同时感知所有信道。
建议关闭不必要的 BLE 扫描，并在调好 LD2410C 后评估关闭雷达自身蓝牙。
上报 radar_presence、csi_activity、csi_valid 和 occupancy，分别保留来源。
第一版规则：雷达有人立即占用；雷达正常且无人时，仅新鲜、已标定的 CSI 可提供一次
最多 5 秒离开宽限；持续 CSI 活动不能不断延长。雷达通信失效时上报 unknown。
这些参数是测试起点，不是经过准确率验证的产品参数。

五、软件文件
firmware/radar_baseline.yaml：ESPHome 雷达独立调试配置，需要本地 secrets.yaml。
该配置尚未编译/烧录，也不实现 CSI。
firmware/fusion_reference.py：可执行的融合规则参考，不是 ESP32 固件或 CSI 检测算法。
firmware/test_fusion.py：6 个规则测试，已通过。
完整 CSI 集成应基于乐鑫 ESP-CSI / esp-radar / esp_wifi_sensing，在 ESP-IDF 下完成；
不要假设标准 ESPHome 固件安装后就同时有 CSI。
官方资料：https://github.com/espressif/esp-csi

六、已完成检查
KiCad ERC：0 条违规。
KiCad DRC（含铜皮重填）：0 条违规、0 未连接项。
原理图/PCB parity：0 项不一致。
原理图、PCB full、交叉分析、Gerber、EMC 和热分析脚本均已运行，结果在 analysis/。
交叉分析：0 条自动提示，详见 analysis/cross.json。
使用 KiCad 内置 ngspice DLL 验证理想 R5/C8 复位 RC：63% 上升时间约 10.08ms，
与 10k / 1uF 的 10ms 时间常数相符。没有模拟降压芯片闭环、射频或 USB 信号完整性。

七、尚需工程验证的事项
1. EMC 分析仍提示 USB D- 层间转换附近的返回路径和部分参考地间隙。已添加地过孔，
   但没有将所有高速回流建议完全满足。需要检查 USB 实际枚举/插拔与波形，必要时
   调整为更紧凑的 USB 成对布线或四层板。当前不是受控阻抗/USB 认证设计。
2. 自动分析器把 U3 USBLC6 当普通 IC，报“缺少去耦”。U3 是保护二极管阵列，
   该项不能直接当成数字 IC 去耦错误；其 VBUS 钳位连接需按 ST 应用图审查和做 ESD 测试。
3. 降压电源谐波和双面铜皮的返回路径需要 EMC 实测；自动分析不能证明合规。
4. 热分析脚本未建立有效器件耗散模型，结果为 SKIPPED，不能解读为温升通过。
5. 未做元件生命周期完整审计。两次 LCSC 搜索未返回目标主控/降压芯片，
   BOM 没有声称已确认库存或价格；下单前核实器件型号、替代料和封装。
6. USB 输入按外部 5V/1A 供电目标设计，没有 CC 电流广告检测、PD 协商或 USB 枚举限流。
   任意电脑 USB 端口能否直接供电没有保证；USB 浪涌/输入电容还需评估。
7. LD2410C 推荐 5V。测量电源、保险丝和连接线后的雷达端电压，避免线损造成工作异常。
8. U1 标准封装包含 0.2mm 热过孔。与板厂确认钻孔、阻焊和中心焊盘焊接工艺。
9. 未做外壳设计、雷达罩材料验证、天线匹配/装机辐射验证或跨房间 CSI 标定。
10. 这是首版设计，没有旧版差异报告，也没有实物上电记录。

八、打样与调试顺序
先做少量工程样机。检查 5V 与 3.3V 对地阻值及焊接，限流电源上电并确认 3.3V。
检查 PCB 天线净空，避免金属、螺丝、屏蔽层或雷达板靠近天线，再启用 Wi-Fi。测试 BOOT/RESET/USB/UART0。
断电连接雷达，核对五针次序，再验证 GPIO OUT 与 UART 数据一致。
测试 Wi-Fi 发包时的电源纹波、USB 插拔/恢复、连续运行和温升。
雷达稳定后启用 CSI，记录原始状态，对比静坐、走动、空房、风扇、隔壁人员活动。
完成这些测试及 EMC/USB 风险处理后，再考虑量产冻结。

九、制造文件与装配范围
prototype-fabrication/ 中的 Gerber、钻孔和 positions.csv 仅供工程打样评估。
BOM.csv 为主板物料，安装孔不属于电子采购物料。
另需 HLK-LD2410C、五针连接线和 USB 线/电源，无需外接 Wi-Fi 天线。
雷达、连接线、外壳不包含在主板 SMT 装配坐标内。
生产文件未提交任何厂商，也没有采购/下单。

十、资料与依据
器件资料链接见 BOM.csv 和 datasheets/sources.json；厂商 PDF 保留在本地工作目录，不随公开设计包分发。
LD2410C 手册 V1.09 第 8 页：1 TX、2 RX、3 OUT、4 GND、5 VCC。
AP63203 DS41326 第 2 页：1 FB、2 EN、3 VIN、4 GND、5 SW、6 BST；固定 3.3V。
USBLC6 第 1 页：1/6 IO1、3/4 IO2、2 GND、5 VBUS。
S3 模组 v1.8 的 Pin Definitions / Boot Configurations 与实际连线作手工交叉检查。
元件数据手册和原始 CAD 核对是引脚依据；自动分析器提示仅为辅助信息。

J2 每个引脚旁标 TX / RX / OUT / GND / VCC，并在方形 1 脚旁标 1。
TX/RX 从雷达引脚视角命名，VCC 为 5V。CSI 覆盖效果需重新验证。


用户提供 LD2410C-P 规格书：正文为 HLK-LD2410C V1.00。第8页确认五针顺序，第18页确认5V、供电能力大于200mA及3.3V IO。已在本地归档并与J2核对；该 PDF 不随公开设计包分发。

紧凑版更新（2026-10-14）
PCB 包络尺寸为 45 x 50mm，面积较 60 x 65mm 减少约 42%。
保留自带 PCB 天线的 ESP32-S3-WROOM-1-N8R8，顶部天线缺口 19.5 x 5.3mm。
PCB 尺寸不等于整机外形：天线部分及 USB 插座可能超出板框，外壳按三维模型确认。
三项完整品牌丝印集中在背面：ESP32S Presence Radar / www.esp32s.com /
PCB manufactured by DIYIPCB。正面上部另有两行产品名称，主控旁标 ESP32 S3。
J2 正面逐针：TX / RX / OUT / GND / VCC（5V）。
J3 正面逐针：3V3 / GND / SDA / SCL。
J4 正面逐针：GND / TX0 / RX0 / GPIO10。
TX0/RX0 是从 ESP32 主控视角标识；J2 TX/RX 是从雷达模组视角标识。
J1 为 USB-C：背面对应位置标 USB-C、VBUS=5V、D-、D+、GND、CC1/CC2。
USB-C 触点间距过小，采用可读信号说明，不将微小触点误标成排针引脚。
SW1 = RESET（重启）；SW2 = BOOT（进入下载模式）。
手动进入下载：按住 BOOT，按一下 RESET，再释放 BOOT。
器件值、主控引脚分配及雷达连接顺序保持不变，所有器件位置和布线已重新设计。
安装孔中心坐标（以 PCB 左上包络角为原点，单位mm）：
H1 (2.5,27.5), H2 (42,3), H3 (3,48), H4 (42,47)。
R5/C8 元件及电气连接未变化，复用原版理想复位 RC 仿真结果。
紧凑版仍为未上电样机设计，需验证温升、USB、EMC 与 CSI 现场表现。
不要把 DRC 通过理解为电源、射频、USB 或人体感应性能已通过实测。




母座叠装修订 R1.2
J2 正面从上至下：TX、RX、OUT、GND、VCC；TX 方形 1 脚在上，VCC 5 脚在下。
LD2410C 天线朝上，板身朝内覆盖主板，预计模块包络位于 45x50mm 主板范围内。
J2、J3 靠右微移，避免 J2 与电感 L1 冲突；C5 移到右下，全部引脚定义保持不变。
J2/J3/J4 均为母座，丝印定义齐全；J1 不变。
装配示意按 16x22mm、针排居中近似绘制；针排距板边、插接高度、下方器件间隙需用样品确认，不可直接用于外壳开模。
叠装不等于已验证无无线互扰。母座高度会影响外壳高度，需实测 Wi-Fi/CSI/雷达共同运行。
最新改动与限制见 REVISION-R1.2.txt、analysis/validation-summary.json。


母座叠装修订 R1.2
J2 正面从上至下：TX、RX、OUT、GND、VCC；TX 方形 1 脚在上，VCC 5 脚在下。
LD2410C 天线朝上，板身朝内覆盖主板，预计模块包络位于 45x50mm 主板范围内。
J2、J3 靠右微移，避免 J2 与电感 L1 冲突；C5 移到右下，全部引脚定义保持不变。
J2/J3/J4 均为母座，丝印定义齐全；J1 不变。
装配示意按 16x22mm、针排居中近似绘制；针排距板边、插接高度、下方器件间隙需用样品确认，不可直接用于外壳开模。
叠装不等于已验证无无线互扰。母座高度会影响外壳高度，需实测 Wi-Fi/CSI/雷达共同运行。
最新改动与限制见 REVISION-R1.2.txt、analysis/validation-summary.json。

R1.2 EMC自动分析仍有风险提示，不能替代实测；USB参考地和电源噪声需验证，热分析仍为SKIPPED。
