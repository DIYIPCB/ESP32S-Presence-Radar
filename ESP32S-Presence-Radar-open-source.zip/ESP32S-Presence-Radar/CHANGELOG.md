# Changelog

## R1 prototype — 2026-10-14

- Publish the 45 × 50 mm KiCad 10 mainboard design.
- Integrated ESP32-S3-WROOM-1 antenna and top antenna clearance notch.
- Add J1/J2/J3/J4 signal legends, RESET/BOOT and ESP32 S3 markings.
- Set product branding to ESP32S Presence Radar.
- Include prototype manufacturing outputs and saved ERC/DRC checks.
- Include uncompiled radar-only ESPHome example and six tested Python fusion rules.
- Hardware untested; complete Wi-Fi CSI integration not implemented.
