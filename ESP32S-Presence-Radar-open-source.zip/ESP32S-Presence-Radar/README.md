# ESP32S Presence Radar

## Purchase and documentation

**[Buy on ESP32S — USD $29 per kit](https://esp32s.com/product/esp32s-presence-radar/)** · [Product Wiki](https://esp32s.com/wiki/esp32s-presence-radar/)

Kit: assembled mainboard + HLK-LD2410C radar + connection cable; no enclosure, USB cable or power adapter. Made to order: 5-day production lead time after order/payment confirmation; dispatch after production and checks, plus shipping transit time. R1 development prototype; complete CSI firmware is not supplied.

45 × 50 mm ESP32-S3 人体存在感应主板，外接 HLK-LD2410C 24 GHz 雷达，预留 Wi-Fi CSI 辅助感知开发路线。

**当前版本：R1 工程样机设计，尚未实物上电验证。完整 CSI 固件尚未实现。**

![Mainboard 3D front](preview/presence-radar-3d-front.png)
![Mainboard 3D back](preview/presence-radar-3d-back.png)

## 硬件

- ESP32-S3-WROOM-1-N8R8，内置 PCB 天线，无需外接 Wi-Fi 天线。
- 45 × 50 mm，两层 PCB，1.6 mm FR-4，四个 M2 安装孔。
- USB-C 5 V 输入与原生 USB 数据/下载；AP63203 固定 3.3 V 降压。
- 外接雷达 UART + OUT；I²C、UART0 和 GPIO 扩展。
- SW1 RESET，SW2 BOOT；产品丝印 ESP32S Presence Radar。
- 网站：www.esp32s.com；PCB manufactured by DIYIPCB。

顶部有天线缺口，模组天线和 USB 插座可能超出板框；PCB 尺寸不等于整机外形。
雷达模组、线缆和外壳不包含在主板 SMT BOM 中。无电池或充电管理。

## 打开设计

使用 **KiCad 10** 打开根目录 `presence_radar_csi_r1.kicad_pro`。
原理图、PCB、本地符号和封装库均已包含。3D 模型使用 KiCad 10 标准模型库，需安装该库。

| 内容 | 位置 |
| --- | --- |
| 原理图与 PCB 源文件 | 根目录 `.kicad_sch` / `.kicad_pcb` |
| 主板 BOM | [BOM.csv](BOM.csv) |
| Gerber、钻孔、贴片坐标 | [prototype-fabrication/](prototype-fabrication/) |
| 预览 | [preview/](preview/) |
| 中文工程说明与风险项 | [docs/design-notes-zh.txt](docs/design-notes-zh.txt) |
| 器件资料链接 | [docs/datasheet-links.md](docs/datasheet-links.md) |
| 检查摘要 | [analysis/validation-summary.json](analysis/validation-summary.json) |

## 接口

| 接口 | 逐针定义 |
| --- | --- |
| J1 USB-C | VBUS 5 V，D− GPIO19，D+ GPIO20，GND；CC1/CC2 各 5.1 kΩ 下拉 |
| J2 雷达 | 1 TX → GPIO5；2 RX ← GPIO4；3 OUT → GPIO6；4 GND；5 VCC 5 V |
| J3 I²C | 1 3V3；2 GND；3 SDA GPIO8；4 SCL GPIO9 |
| J4 调试 | 1 GND；2 TX0 GPIO43；3 RX0 GPIO44；4 GPIO10 |

J2 TX/RX 从雷达视角命名；J4 TX0/RX0 从主控视角命名。雷达 UART 256000 baud、3.3 V 电平。
手动下载：按住 BOOT，按一下 RESET，然后释放 BOOT。

## 软件状态

`firmware/radar_baseline.yaml` 是 ESPHome 雷达独立调试配置，尚未编译或烧录，不含 CSI。
复制 `firmware/secrets.example.yaml` 为同目录 `secrets.yaml` 并填写本地 Wi-Fi 配置；不要提交密码。

`firmware/fusion_reference.py` 是 Python 融合规则参考，**不是 ESP32 固件或 CSI 检测算法**。
雷达为主要数据源，CSI 仅在有效、已标定且新鲜时提供一次最多 5 秒离开宽限；雷达失联上报 unknown。
运行规则测试：

```sh
python -m unittest discover -s firmware -p "test_*.py" -v
```

CSI 后续开发参考 [Espressif ESP-CSI](https://github.com/espressif/esp-csi)。
CSI 需要合适的 Wi-Fi 数据来源，覆盖效果与环境有关，不能视为独立雷达。

## 验证与限制

2026-10-14 保存的检查结果：ERC 0，DRC 0，未连接 0，原理图/PCB 不一致 0；融合规则测试 6 项通过。
理想复位 RC 仿真约 10.08 ms，结果仅适用于该 RC 子电路。

尚未完成实物上电、电源纹波、USB 枚举及信号完整性、EMC/ESD、温升、天线装机和人体感应准确率测试。
当前 USB 为两层非受控阻抗布线，回流路径仍需验证；BOM 库存、价格及替代料尚未核实。
制造文件供少量工程打样评估，检查通过不代表可直接量产。

## 开源许可

- 项目原创硬件及制造数据：**CERN-OHL-P-2.0**。
- 原创示例代码、测试、文档和预览：**MIT**。
- 随附 KiCad 封装集合：保留上游 **CC-BY-SA-4.0 与 KiCad 例外条款**。

完整条款见 [LICENSE](LICENSE)、[LICENSES/](LICENSES/) 和 [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md)。
第三方器件文档提供链接；品牌和商标权不随开源许可授予。

## English

Open KiCad 10 prototype of an ESP32-S3 presence sensor carrier, 45 × 50 mm,
using an external HLK-LD2410C radar. Integrated Wi-Fi antenna, USB-C power/data,
and expansion headers. Hardware has not been powered on or qualified.
Radar-only ESPHome configuration is uncompiled; CSI firmware remains future work.
Hardware: CERN-OHL-P-2.0. Original software/docs: MIT. See third-party notices.
