# Third-party notices

The pinned footprint collection in `libraries/` is derived from the KiCad 10
standard footprint library, compiled by the KiCad community:
https://gitlab.com/kicad/libraries/kicad-footprints

It retains CC-BY-SA-4.0 with the KiCad library exception. Full terms are in
`libraries/LICENSE.md` and `LICENSES/CC-BY-SA-4.0.txt`.
Library licensing reference: https://www.kicad.org/libraries/license/

DIYIPCB modifications dated 2026-10-14: the ESP32-S3-WROOM-1 footprint has
project-specific pad metadata and a cropped antenna-region silkscreen outline.
These library adaptations retain the same library licence.
The local `Presence.kicad_sym` is the project's component symbol collection;
any embedded standard KiCad graphical elements retain applicable upstream rights.

Manufacturer datasheets are linked rather than redistributed. ESPHome and
Espressif software dependencies are not bundled or relicensed here.
ESP32 and other manufacturer names belong to their respective owners.
The PCB marking “PCB manufactured by DIYIPCB” is design branding and is not
evidence that a physical PCB has been manufactured.
