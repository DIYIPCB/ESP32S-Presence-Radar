# 器件资料 / Datasheets

- [ESP32-S3-WROOM-1U.pdf](https://documentation.espressif.com/esp32-s3-wroom-1_wroom-1u_datasheet_en.pdf)
- [AP63203.pdf](https://www.diodes.com/assets/Datasheets/AP63200-AP63201-AP63203-AP63205.pdf)
- [USBLC6-2SC6.pdf](https://www.st.com/resource/en/datasheet/usblc6-2.pdf)
- [SRP5030T.pdf](https://www.bourns.com/docs/Product-Datasheets/SRP5030T.pdf)
- [USB4105.pdf](https://gct.co/files/drawings/usb4105.pdf)
- [LD2410C.pdf](https://r0.hlktech.com/download/HLK-LD2410C-24G/1/HLK%20LD2410C%E7%94%9F%E5%91%BD%E5%AD%98%E5%9C%A8%E6%84%9F%E5%BA%94%E6%A8%A1%E7%BB%84%E8%AF%B4%E6%98%8E%E4%B9%A6V1.09.pdf)

完整器件资料链接见根目录 BOM.csv。厂商文档版权归各自权利人。
