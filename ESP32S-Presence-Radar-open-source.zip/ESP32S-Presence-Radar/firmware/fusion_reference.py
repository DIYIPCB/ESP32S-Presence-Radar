"""Executable specification, NOT firmware or a CSI signal processing algorithm.

Radar is authoritative. CSI may grant one bounded exit grace period only.
Repeated CSI motion must not indefinitely retain a radar-clear occupancy state.
"""
from dataclasses import dataclass
from typing import Optional

@dataclass
class Fusion:
    grace_s: float = 5.0
    radar_max_age_s: float = 2.0
    csi_max_age_s: float = 1.0
    occupied: bool = False
    radar_seen: bool = False
    last_radar_at: float = -float('inf')
    radar_present: bool = False
    radar_fault: bool = False
    clear_at: Optional[float] = None
    grace_until: Optional[float] = None

    def update(self, now: float, radar: Optional[bool] = None,
               csi_motion: bool = False, csi_age: float = float('inf'),
               csi_calibrated: bool = False, radar_fault: bool = False):
        if radar_fault:
            self.radar_fault = True
            return None
        if radar is not None:
            self.radar_fault = False
            self.radar_seen = True
            self.last_radar_at = now
            self.radar_present = radar
        if self.radar_fault or not self.radar_seen or now-self.last_radar_at > self.radar_max_age_s:
            return None  # unavailable/unknown, never silently report empty
        if self.radar_present:
            self.occupied = True
            self.clear_at = None
            self.grace_until = None
            return True
        if self.occupied and self.clear_at is None:
            self.clear_at = now
            fresh_csi = csi_calibrated and 0 <= csi_age <= self.csi_max_age_s
            self.grace_until = now+self.grace_s if fresh_csi and csi_motion else now
        if self.occupied and now >= self.grace_until:
            self.occupied = False
        return self.occupied
