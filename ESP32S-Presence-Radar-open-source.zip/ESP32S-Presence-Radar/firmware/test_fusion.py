import unittest
from fusion_reference import Fusion

class FusionTests(unittest.TestCase):
    def test_csi_alone_does_not_assert_presence(self):
        f=Fusion()
        self.assertFalse(f.update(0,False,True,0,True))
    def test_radar_not_overridden_by_csi(self):
        f=Fusion()
        self.assertTrue(f.update(0,True))
    def test_csi_grace_is_bounded(self):
        f=Fusion()
        f.update(0,True)
        self.assertTrue(f.update(1,False,True,0,True))
        for t in [2,3,4,5]:self.assertTrue(f.update(t,False,True,0,True))
        self.assertFalse(f.update(6,False,True,0,True))
    def test_stale_or_uncalibrated_csi_does_not_hold(self):
        for age,cal in [(2,True),(0,False)]:
            f=Fusion();f.update(0,True)
            self.assertFalse(f.update(1,False,True,age,cal))
    def test_radar_timeout_and_fault_are_unknown(self):
        f=Fusion();f.update(0,True)
        self.assertIsNone(f.update(3))
        self.assertIsNone(f.update(4,radar_fault=True))
        self.assertIsNone(f.update(4.5))
        self.assertFalse(f.update(5,False))
    def test_radar_return_resets_grace(self):
        f=Fusion();f.update(0,True);f.update(1,False,True,0,True)
        self.assertTrue(f.update(2,True))
        self.assertFalse(f.update(3,False))

if __name__=='__main__':unittest.main()
